/*
 * Project version information. Generated - do not modify.
 */
package mondrian.olap4j;
/**
 * Version information for the Mondrian olap4j driver. (Generated.)
 */
class MondrianOlap4jDriverVersion {
    static final String NAME = "Mondrian olap4j driver";
    static final String VERSION = "3.3.0.14703";
    static final int MAJOR_VERSION = 3;
    static final int MINOR_VERSION = 300014703;
}

// End MondrianOlap4jDriverVersion.java