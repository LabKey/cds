// This class is generated. Do NOT modify it, or
// add it to source control.

package mondrian.resource;
import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eigenbase.resgen.*;

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from /build/hudson/jobs/Mondrian_Release_Assemble/workspace/src/main/mondrian/resource/MondrianResource.xml
 * on Wed Oct 19 14:21:46 GMT-05:00 2011.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 */

public class MondrianResource_de extends MondrianResource {
    public MondrianResource_de() throws IOException {
    }
}

// End MondrianResource_de.java
